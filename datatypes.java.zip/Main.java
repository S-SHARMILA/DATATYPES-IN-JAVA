import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    float b=sc.nextFloat();
	    char c=sc.next().charAt(0);
	    long d=sc.nextLong();
	    sc.nextLine();
	    String e=sc.nextLine();
	    System.out.println(a);
	    System.out.println(b);
	    System.out.println(c);
	    System.out.println(d);
	    System.out.println(e);
	}
}